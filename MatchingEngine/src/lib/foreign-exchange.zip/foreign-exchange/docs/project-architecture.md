## Creating new components

Components are divided into two categories: shared (dumb) components and feature (smart) components.

Shared/presenter/dumb components are responsible for rendering small bits and pieces of the UI. They do not have any knowledge of the outer business scope but are instead controlled by smart/feature components, with data being provided externally.

Smart components act as data organizers. They are responsible for data fetching, sharing state between child components, and organizing them into a complex feature.

The idea behind the Dumb/Smart component approach is to increase the reuse of functionality and subdivide the app into smaller, reusable parts.

Every component should make use of a component service for any kind of data manipulation to achieve a separation of concerns between pure UI presentation and UI data handling. This promotes the reuse of templates and enables component services to encapsulate logic that can be used across multiple components/features.

## Api communication

API communication is performed by services located in `shared/infrastructure`. These services are agnostic to application features and focus on basic data retrieval and schema validation without adding unnecessary processing overhead. Infrastructure services must not depend on any higher-level layers, such as dumb/smart components or business logic services.

## Shared business logic

Stateful services that provide state to multiple application features are located in the `shared/services` folder. These services may be utilized when navigating between app pages or across use case steps. Each service should follow the **Single Responsibility Principle** and cover only one business logic/domain area.

## Testing

TODO: you can describe your approach here
