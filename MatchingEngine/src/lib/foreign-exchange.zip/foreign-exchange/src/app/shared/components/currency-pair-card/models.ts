export type CurrencyPairCardData = {
	title: string;
	currencyPair: string;
	exchangeRate: string;
	lastFetched: string;
};
