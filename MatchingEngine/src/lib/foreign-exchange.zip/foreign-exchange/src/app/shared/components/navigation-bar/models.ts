export type NavigationBarRoute = { title: string; path: string };
