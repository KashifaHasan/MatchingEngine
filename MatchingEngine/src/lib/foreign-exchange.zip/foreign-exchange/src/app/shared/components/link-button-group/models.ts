export type LinkButtonGroupItem = {
	label: string;
	path: string;
};
