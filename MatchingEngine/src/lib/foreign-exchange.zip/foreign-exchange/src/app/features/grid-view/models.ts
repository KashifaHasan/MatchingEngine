export type GridViewRowData = {
	fromCurrencyCode: string;
	toCurrencyCode: string;
	bidPrice: number;
	askPrice: number;
	lastUpdated: string;
};
