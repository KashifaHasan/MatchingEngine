// place your Vantage api key here to get real data
export const aplhaVantageApiKey = '';
