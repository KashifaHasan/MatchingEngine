export type Environment = {
	apiConfigs: {
		alphaVantage: {
			url: string;
		};
	};
};
